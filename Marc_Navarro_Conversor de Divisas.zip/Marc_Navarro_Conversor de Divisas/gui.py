import tkinter as tk
from tkinter import ttk, messagebox
from logica import cargar_datos, convertir   # importar funciones

root = tk.Tk()
root.title("Conversor BCE")

# cargar al iniciar
fecha, tasas = cargar_datos()

# --- GUI ---
tk.Label(root, text="Cantidad:").grid(row=0, column=0)
entry_cantidad = tk.Entry(root)
entry_cantidad.grid(row=0, column=1)

tk.Label(root, text="Origen:").grid(row=1, column=0)
combo_origen = ttk.Combobox(root, values=list(tasas.keys()))
combo_origen.grid(row=1, column=1)
combo_origen.set("EUR")

tk.Label(root, text="Destino:").grid(row=2, column=0)
combo_destino = ttk.Combobox(root, values=list(tasas.keys()))
combo_destino.grid(row=2, column=1)
combo_destino.set("USD")

# acción botón
def btn_convertir():
    try:
        cantidad = float(entry_cantidad.get())
    except:
        messagebox.showerror("Error", "Introduce un número válido.")
        return

    ori = combo_origen.get()
    des = combo_destino.get()

    res = convertir(cantidad, ori, des, tasas)
    label_res.config(text=f"{res:.4f} {des}")

btn = tk.Button(root, text="Convertir", command=btn_convertir)
btn.grid(row=3, column=0, columnspan=2)

label_res = tk.Label(root, text="Resultado:")
label_res.grid(row=4, column=0, columnspan=2)

tk.Label(root, text=f"Datos del: {fecha}").grid(row=5, column=0, columnspan=2)

root.mainloop()
