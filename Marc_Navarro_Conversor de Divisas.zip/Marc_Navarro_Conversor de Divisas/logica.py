import requests
import xml.etree.ElementTree as ET

# cargar xml
def cargar_datos():
    url = "https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml"
    r = requests.get(url)
    root = ET.fromstring(r.content)

    ns = {"def": "http://www.ecb.int/vocabulary/2002-08-01/eurofxref"}

    # fecha
    cube_time = root.find(".//def:Cube/def:Cube", ns)
    fecha = cube_time.attrib["time"]

    # tasas
    tasas = {"EUR": 1.0}
    for c in cube_time.findall("def:Cube", ns):
        moneda = c.attrib["currency"]
        rate = float(c.attrib["rate"])
        tasas[moneda] = rate

    return fecha, tasas


# convertir divisas
def convertir(cantidad, origen, destino, tasas):
    tasa_ori = tasas[origen]
    tasa_des = tasas[destino]

    eur = cantidad / tasa_ori
    resultado = eur * tasa_des
    return resultado

