from matriculas_alumnos.dominio.alumno import Alumno
from matriculas_alumnos.servicio.alumnos_matriculados import AlumnosMatriculados

def mostrar_menu():
    """Muestra el menú de opciones en la consola."""
    print("\n--- MENÚ ---")
    print("1) Matricular alumno")
    print("2) Listar alumnos")
    print("3) Eliminar archivo de alumnos")
    print("4) Salir")
    print("------------")

def main():
    """Función principal que ejecuta el programa."""
    opcion = None
    while opcion != '4':
        mostrar_menu()
        opcion = input('Selecciona una opción: ')

        if opcion == '1':
            nombre_alumno = input('Introduce el nombre del alumno a matricular: ')
            alumno = Alumno(nombre_alumno)
            AlumnosMatriculados.matricular_alumno(alumno)
        elif opcion == '2':
            AlumnosMatriculados.listar_alumnos()
        elif opcion == '3':
            AlumnosMatriculados.eliminar_alumnos()
        elif opcion == '4':
            print('Saliendo del programa...')
        else:
            print('Opción no válida. Por favor, elige una opción del 1 al 4.')

if __name__ == '__main__':
    main()