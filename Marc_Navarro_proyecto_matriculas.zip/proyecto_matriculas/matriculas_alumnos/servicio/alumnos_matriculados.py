import os
# PyCharm puede que subraye esta línea en rojo al principio, pero es correcto.
# Se resolverá cuando ejecutes el programa desde el archivo principal.
from matriculas_alumnos.dominio.alumno import Alumno

class AlumnosMatriculados:
    """
    Realiza las operaciones sobre el fichero de alumnos.
    """
    ruta_archivo = 'alumnos.txt'

    @classmethod
    def matricular_alumno(cls, alumno):
        try:
            with open(cls.ruta_archivo, 'a', encoding='utf8') as archivo:
                archivo.write(f'{alumno.nombre}\n')
            print(f"Alumno '{alumno.nombre}' matriculado correctamente.")
        except Exception as e:
            print(f'Ocurrió un error al matricular: {e}')

    @classmethod
    def listar_alumnos(cls):
        try:
            with open(cls.ruta_archivo, 'r', encoding='utf8') as archivo:
                print('--- Listado de Alumnos ---')
                if os.path.getsize(cls.ruta_archivo) > 0:
                    for linea in archivo:
                        print(linea.strip())
                else:
                    print('No hay alumnos matriculados.')
                print('--------------------------')
        except FileNotFoundError:
            print('El archivo de alumnos aún no existe.')
        except Exception as e:
            print(f'Ocurrió un error al listar: {e}')

    @classmethod
    def eliminar_alumnos(cls):
        try:
            os.remove(cls.ruta_archivo)
            print(f'Archivo "{cls.ruta_archivo}" eliminado con éxito.')
        except FileNotFoundError:
            print('El archivo que intentas eliminar no existe.')
        except Exception as e:
            print(f'Ocurrió un error al eliminar el archivo: {e}')