import csv

def consolidar_notas(uf1_file, uf2_file, output_file):
    """
    Lee las notas de dos ficheros CSV (con delimitador ';')
    y escribe un nuevo fichero CSV consolidado.
    """
    alumnos_data = {}  # Usará el Id como clave

    # --- Leer el primer fichero (UF1) ---
    try:
        with open(uf1_file, mode='r', newline='', encoding='latin-1') as f_uf1:
            reader_uf1 = csv.DictReader(f_uf1, delimiter=';')
            for row in reader_uf1:
                alumno_id = row['Id']
                alumnos_data[alumno_id] = {
                    'Id': alumno_id,
                    'Nombre': row['Nombre'],
                    'Apellidos': row['Apellidos'],
                    'UF1': row['UF1']
                }
    except FileNotFoundError:
        print(f"Error: No se encontró el archivo '{uf1_file}'.")
        print("Asegúrate de que esté en la misma carpeta que el script.")
        return
    except KeyError as e:
        print(f"Error: El archivo '{uf1_file}' no tiene la columna esperada: {e}.")
        print("Revisa los encabezados del CSV. ¿Están escritos exactamente igual?")
        return
    except Exception as e:
        print(f"Ha ocurrido un error inesperado leyendo {uf1_file}: {e}")
        return

    # --- Leer el segundo fichero (UF2) ---
    try:
        with open(uf2_file, mode='r', newline='', encoding='latin-1') as f_uf2:
            reader_uf2 = csv.DictReader(f_uf2, delimiter=';')
            for row in reader_uf2:
                alumno_id = row['Id']
                if alumno_id in alumnos_data:
                    alumnos_data[alumno_id]['UF2'] = row['UF2']
                else:
                    alumnos_data[alumno_id] = {
                        'Id': alumno_id,
                        'Nombre': row['Nombre'],
                        'Apellidos': row['Apellidos'],
                        'UF1': 'N/A',
                        'UF2': row['UF2']
                    }
    except FileNotFoundError:
        print(f"Error: No se encontró el archivo '{uf2_file}'.")
        print("Asegúrate de que esté en la misma carpeta que el script.")
        return
    except KeyError as e:
        print(f"Error: El archivo '{uf2_file}' no tiene la columna esperada: {e}.")
        print("Revisa los encabezados del CSV. ¿Están escritos exactamente igual?")
        return
    except Exception as e:
        print(f"Ha ocurrido un error inesperado leyendo {uf2_file}: {e}")
        return

    # --- Escribir el fichero de salida ---
    fieldnames = ['Id', 'Apellidos', 'Nombre', 'UF1', 'UF2']
    output_rows = []

    try:
        sorted_ids = sorted(alumnos_data.keys(), key=int)
    except ValueError:
        sorted_ids = sorted(alumnos_data.keys())

    for alumno_id in sorted_ids:
        alumno = alumnos_data[alumno_id]
        output_rows.append({
            'Id': alumno['Id'],
            'Apellidos': alumno['Apellidos'],
            'Nombre': alumno['Nombre'],
            'UF1': alumno.get('UF1', 'N/A'),
            'UF2': alumno.get('UF2', 'N/A')
        })

    try:
        with open(output_file, mode='w', newline='', encoding='utf-8') as f_output:
            writer = csv.DictWriter(f_output, fieldnames=fieldnames, delimiter=';')
            writer.writeheader()
            writer.writerows(output_rows)
        print(f"¡Éxito! Fichero '{output_file}' creado correctamente.")
    except IOError as e:
        print(f"Error: No se pudo escribir en el archivo '{output_file}': {e}")
    except Exception as e:
        print(f"Ha ocurrido un error inesperado escribiendo el archivo: {e}")


if __name__ == "__main__":
    archivo_uf1 = 'Notas_Alumnos_UF1.csv'
    archivo_uf2 = 'Notas_Alumnos_UF2.csv'
    archivo_salida = 'Notas_Consolidadas.csv'
    consolidar_notas(archivo_uf1, archivo_uf2, archivo_salida)
